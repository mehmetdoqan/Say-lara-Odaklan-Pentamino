const PIECES=[
{id:'I',color:'#B9C19A'},
{id:'Y',color:'#4B1FD3'},
{id:'P',color:'#9A7420'},
{id:'L',color:'#3E8A2C'},
{id:'U',color:'#C9A457'},
{id:'N',color:'#B12C63'},
{id:'X',color:'#7B15A9'}
];

const SOLUTIONS=[
[
['.','I','I','I','I','I'],
['L','L','L','L','N','N'],
['L','X','N','N','N','Y'],
['X','X','X','P','Y','Y'],
['U','X','U','P','P','Y'],
['U','U','U','P','P','Y']
]
];
