const COLORS = Object.fromEntries(PIECES.map(p => [p.id, p.color]));
let current = 1;

function render(){
const grid = SOLUTIONS[current-1];
const el = document.getElementById('solutionsGrid');
el.innerHTML='';
const board=document.createElement('div');
board.className='board';

for(let r=0;r<6;r++){
for(let c=0;c<6;c++){
let v=grid[r][c];
let cell=document.createElement('div');
cell.className='cell';
if(v==='.'){cell.classList.add('empty');}
else{cell.style.background=COLORS[v];}
board.appendChild(cell);
}}
el.appendChild(board);
}

function nav(){
const nav=document.getElementById('numberNav');
nav.innerHTML='';
for(let i=1;i<=SOLUTIONS.length;i++){
let b=document.createElement('button');
b.innerText=i;
b.onclick=()=>{current=i;render();};
nav.appendChild(b);
}
}

render();nav();
